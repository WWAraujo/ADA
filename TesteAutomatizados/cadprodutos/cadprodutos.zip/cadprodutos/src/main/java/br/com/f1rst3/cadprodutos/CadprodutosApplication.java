package br.com.f1rst3.cadprodutos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadprodutosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadprodutosApplication.class, args);
	}

}
