package SQL.DAO;

public class ClienteDAO {

    public static String url = "jdbc:mysql://localhost:3306/BancoADA";
    public static String login = "root";
    public static String senha = "";

    public static void InserirPessoaFisica (Object obj){

    }

    public static void InserirPessoaJuridica (Object obj){

    }

    public static void Transferencia (Object obj){

    }

    public static void Deposito (Object obj){

    }

    public static void Saque (Object obj){

    }

}
